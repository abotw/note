/*
 * File: acronym.c
 * ---------------
 * Implements and tests the Acronym function.
 */

#include <stdio.h>

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/* Function prototypes */

string Acronym(string str);

/* Main program */

int main(int argc, string args[]) {
    printf("This program generates acronyms.\n");
    printf("Indicate end of input with a blank line.\n");
    while (true) {
        printf("String: ");
        string str = GetLine();
        if (StringEqual(str, ""))
            break;
        printf("The acronym is %s.\n", Acronym(str));
    }
    return 0;
}

/*
 * Function: Acronym
 * Usage: acronym = Acronym(str);
 * ------------------------------
 * Takes a string consisting of a sequence of words and returns
 * the acronym formed by taking the initial letter of each word.
 * The program operates by finding each space in the word and
 * then concatenating the following letter onto the acronym so
 * far.  At the beginning, the acronym is set to be the first
 * character in the string.
 */

string Acronym(string str) {
    string acronym = CharToString(IthChar(str, 0));
    int pos = 0;
    while (true) {
        pos = FindChar(' ', str, pos + 1);
        if (pos == -1)
            break;
        acronym = ConcatString(acronym, CharToString(IthChar(str, pos + 1)));
    }
    return (acronym);
}
