# SimpleCSLib

The `SimpleCSLib` package is a pure C library for introductory CS. This is a fork from `cslib` originally developed by Eric Roberts.

The history of `cslib` could be found here: 

- [Using C in CS1: The Stanford experience](https://cs.stanford.edu/people/eroberts/papers/SIGCSE-1993/UsingCInCS1.pdf), February 1993
- [A C-based graphics library for CS1](https://cs.stanford.edu/people/eroberts/papers/SIGCSE-1995/CBasedGraphicsLibrary.pdf), March 1995

## Environment

For Windows, download and install [Git](https://git-scm.com/), [CMake](https://cmake.org/), [MSYS2](https://www.msys2.org/).

Open MSYS2 UCRT terminal, and install the following packages:

```
pacman -Sy mingw-w64-ucrt-x86_64-toolchain
```

For editing, complling and debugging, **VS Code** + **CMake Tools** are highly recommanded.
