/*
 * File: ucfile.c
 * --------------
 * This program updates the contents of a file by converting all
 * letters to upper case.
 */

#include <ctype.h>

#include "genlib.h"
#include "simpio.h"

/* Private function prototypes */

static void UpperCaseCopy(stream infile, stream outfile);
bool openFile(stream* infile, string filename, string mode);
string promptUserForFile(stream* file, string mode, string prompt);

/* Main program */

int main(int argc, string args[]) {
    printf("This program converts a file to upper case.\n");

    // string filename;
    // stream infile;
    // while (true) {
    //     printf("File name: ");
    //     filename = GetLine();
    //     // infile = fopen(filename, "r");
    //     // if (infile != NULL) {
    //     //     break;
    //     // }
    //     if (openFile(&infile, filename, "r")) {
    //         break;
    //     }
    //     printf("File %s not found -- try again.\n", filename);
    // }

    stream infile = NULL;
    // infile：你好，请更新我的内容。
    string filename = promptUserForFile(&infile, "r", "File name:"); // 传引用
    // infile：谢谢，我打开了 filename 文件。

    string tempfilename = tmpnam(NULL);
    stream outfile;
    if (!openFile(&outfile, tempfilename, "w")) {
        Error("Can't open temporary file");
    }
    // stream outfile = fopen(tempfile, "w");
    // if (outfile == NULL) {
    //     Error("Can't open temporary file");
    // }
    UpperCaseCopy(infile, outfile);
    fclose(infile);
    fclose(outfile);
    if (remove(filename) != 0 || rename(tempfilename, filename) != 0) {
        Error("Unable to rename temporary file");
    }
}

/*
 * Function: UpperCaseCopy
 * Usage: UpperCaseCopy(infile, outfile);
 * --------------------------------------
 * This function copies the contents of infile to outfile,
 * converting alphabetic characters to upper case as it does so.
 * The client is responsible for opening and closing the files.
 */

static void UpperCaseCopy(stream infile, stream outfile) {
    int ch;
    while ((ch = getc(infile)) != EOF) {
        putc(toupper(ch), outfile);
    }
}

bool openFile(stream* file, string filename, string mode) {
    *file = fopen(filename, mode);
    if (*file != NULL) {
        return true;
    }
    return false;
}

string promptUserForFile(stream* file, string mode, string prompt) {
    string filename = NULL;
    while (true) {
        printf("%s ", prompt);
        filename = GetLine();
        if (openFile(file, filename, "r")) {
            return filename;
        }
        printf("File %s not found -- try again.\n", filename ? filename : "");
        if (filename != NULL) {
            FreeBlock(filename);
        }
    }
}