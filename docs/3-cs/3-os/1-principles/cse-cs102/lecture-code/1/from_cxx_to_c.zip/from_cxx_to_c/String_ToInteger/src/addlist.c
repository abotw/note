/*
 * File: addlist.c
 * ---------------
 * This program adds a list of numbers.  The end of the input
 * is indicated by entering a blank line as a sentinel value.
 */

#include <stdio.h>

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

int main(int argc, string args[]) {
    printf("This program adds a list of numbers.\n");
    printf("Signal end of list with a blank line.\n");
    int total = 0;
    while (true) {
        printf(" ? ");
        string line = GetLine();
        if (StringEqual(line, ""))
            break;
        total += StringToInteger(line);
    }
    printf("The total is %d\n", total);
    return 0;
}
