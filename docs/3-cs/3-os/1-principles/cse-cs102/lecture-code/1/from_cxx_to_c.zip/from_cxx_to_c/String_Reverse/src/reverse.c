/*
 * File: reverse.c
 * ---------------
 * This file defines the function ReverseString(str),
 * which returns str with its characters reversed.
 */

#include <stdio.h>

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/* Function prototypes */

string ReverseString(string str);

/* Main program */

int main(int argc, string args[]) {
    printf("Enter a string: ");
    string str = GetLine();
    printf("\"%s\" backwards is \"%s\"\n", str, ReverseString(str));
}

/*
 * Function: ReverseString
 * Usage: newstr = ReverseString(str);
 * -----------------------------------
 * Returns a new string consisting of the characters in
 * str in reverse order.
 */

string ReverseString(string str) {
    string result = "";
    for (int i = 0; i < StringLength(str); i++) {
        result = ConcatString(CharToString(IthChar(str, i)), result);
    }
    return (result);
}
