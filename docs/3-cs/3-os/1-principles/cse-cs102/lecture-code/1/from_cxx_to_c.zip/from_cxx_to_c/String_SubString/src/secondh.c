/*
 * File: secondh.c
 * ---------------
 * This file defines the function SecondHalf(str),
 * which returns the second half of its argument.
 */

#include <stdio.h>

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/* Function prototypes */

string SecondHalf(string str);

/* Main program */

int main(int argc, string args[]) {
    printf("Enter a string: ");
    string str = GetLine();
    printf("The second half of \"%s\" is \"%s\"\n", str, SecondHalf(str));
}

/*
 * Function: SecondHalf
 * Usage: newstr = SecondHalf(str);
 * --------------------------------
 * This function returns the second half of the string str.
 * If the string contains an odd number of characters, the
 * center character is included in the result.
 */

string SecondHalf(string str) {
    int len = StringLength(str);
    return (SubString(str, len / 2, len - 1));
}
