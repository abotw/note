/*
 * File: showfile.c
 * ----------------
 * This program reads a file name from the user and displays
 * the contents of that file on the console.
 */

#include "genlib.h"
#include "simpio.h"

/* Main program */

int main(int argc, string args[]) {
    printf("This program displays an input file.\n");

    stream infile;
    while (true) {
        printf("Input file name: ");
        string filename = GetLine();
        infile = fopen(filename, "r");
        if (infile != NULL){
            //FreeBlock(filename);
            break;
        }
        printf("Can't open the file %s.  Try again.\n", filename);
        //FreeBlock(filename);
    }

    char ch;
    while ((ch = getc(infile)) != EOF) {
        putc(ch, stdout);
    }

    fclose(infile);
}
