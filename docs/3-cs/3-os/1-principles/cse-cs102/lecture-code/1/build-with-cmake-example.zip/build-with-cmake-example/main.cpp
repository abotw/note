#include <iostream>
#include "my_lib.hpp"

int main() {

    std::cout << "Hello world!" << std::endl;
    std::cout << my_lib_function() << std::endl;

    return 0;
}