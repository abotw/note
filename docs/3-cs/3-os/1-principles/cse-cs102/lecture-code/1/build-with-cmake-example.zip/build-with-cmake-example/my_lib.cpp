#include <string>
#include "my_lib.hpp"

std::string my_lib_function() {
    return "In library";
}