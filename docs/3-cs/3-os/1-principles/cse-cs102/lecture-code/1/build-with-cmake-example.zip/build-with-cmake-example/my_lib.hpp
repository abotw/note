#pragma once

#include <string>

std::string my_lib_function();